package stepdef;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import POM.pomclass;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
  	pomclass pom;
  	pomclass pom1;
  	pomclass pom2;


    @Given("^Open coaching page$")				
    public void Open() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
 
        d.get("file:C:\\Coaching_Class_Enquiry.html");
        d.manage().window().maximize();
        
       
    }		
    
 @Then("^verify title and text$")					
    public void check() throws Throwable 							
    {    		
	// Thread.sleep(10000);
     //System.out.println("Title is correct-No defect");

	 
	 String a=d.getTitle();
	    if(a.equalsIgnoreCase("online coaching class enquiry form")) 
	    {
	        System.out.println("Title is correct-No defect");

	    }
	    else
	    {
	        System.out.println("Title is not correct-A defect");
	    }
    	 boolean aq=d.getPageSource().contains("Your");
		    if(aq) 
		    {
		        System.out.println("Text is present-No defect");

		    }
		    else
		    {
		        System.out.println("Text is not present-A defect");
		    }
		    //d.close();
	      //throw new PendingException();
       }		
 
 @When("^enter last name and firstname blank than$")					
 public void entername(DataTable dt) throws Throwable 							
 {    		
	 //Thread.sleep(10000);
	 List<List<String>> data = dt.raw();
	 
	 
     pom=new pomclass(d);

	 pom.firstname(data.get(0).get(0));

	 pom.lastname(data.get(0).get(1));
	      //throw new PendingException();

	 }		
 
 @Then("^alert message for entering comes$")					
 public void checkalert() throws Throwable 							
 {    		
	  try
	  {
		  String t=d.switchTo().alert().getText();
		  d.switchTo().alert().accept();

		  System.out.println(t);

		  if(t.equalsIgnoreCase("First Name must be filled out"))
		  {
			  System.out.println("on not entering first name and entering in next box alert with text appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on not entering first name and entering in next box alert with text did not appeared-A defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }
	 //d.close();
    //throw new PendingException();
 	 }		
 //------------------------------------------
 @When("^enter lastnull \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
 public void enter_less_and_and(String fn1, String ln1, String em1) throws Throwable 
 {
	 pom2=new pomclass(d);
     pom2.firstname(fn1);
     pom2.lastname(ln1);
     pom2.email1(em1);

  }

 @Then("^alert message3 for lastname comes$")
 public void alert_message_for_lastname_comes() throws Throwable
 {
	 try
	  {
		  String t=d.switchTo().alert().getText();
		  d.switchTo().alert().accept();

		  System.out.println(t);

		  if(t.equalsIgnoreCase("Last Name must be filled out"))
		  {
			  System.out.println("on  entering first name and not entering in last name an  alert with text appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on  entering first name and not entering in last name alert with text did not appeared-A defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }     //throw new PendingException();
 }

 
 
 
 //------------------------------------------
 
 
 
 
 
 @When("^enter \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
 public void enter_all_and_and_and_anda(String fn, String ln, String em, String mo, String typ) throws Throwable
 {
	 pom1=new pomclass(d);
     pom1.firstname(fn);
     pom1.lastname(ln);
     pom1.email1(em);
     pom1.mobile1(mo);
     pom1.tutiontype(typ);	
 	 
	 
	 // Write code here that turns the phrase above into concrete actions
     //throw new PendingException();
 }
 @Then("^alert message for mobile comes$")					
 public void checkalert1() throws Throwable 							
 {    		
	  try
	  {
		  String t1=d.switchTo().alert().getText();
		  d.switchTo().alert().accept();

		  System.out.println(t1);

		  if(t1.equalsIgnoreCase("Enter numeric value"))
		  {
			  System.out.println("on entering non numeric in mobile an alert appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on entering non numeric in mobile an alert did not appear-No defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }
     //throw new PendingException();
 	 }	
 
 @When("^enter less \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
 public void enter_all_and_and_and_andac(String fn, String ln, String em, String mo, String typ) throws Throwable
 {
	 pom1=new pomclass(d);
     pom1.firstname(fn);
     pom1.lastname(ln);
     pom1.email1(em);
     pom1.mobile1(mo);
     pom1.tutiontype(typ);	
}
 
 @Then("^alert message2 for mobile comes$")					
 public void checkalert12() throws Throwable 							
 {    		
	  try
	  {
		  String t1=d.switchTo().alert().getText();
		  d.switchTo().alert().accept();

		  System.out.println(t1);

		  if(t1.equalsIgnoreCase("Enter 10 digit Mobile number"))
		  {
			  System.out.println("on entering less than 10 mobile an alert appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on entering less than 10 mobile an alert did not appear-No defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }
     //throw new PendingException();
 	 }	
 
 
 
 @When("^enter all \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
 public void enter_all_and_and_and_and_and_and(String fn, String ln, String ema, String mob, String tt, String city, String mode,String enquiry) throws Throwable 
 {
	 pom=new pomclass(d);
     pom.firstname(fn);
     pom.lastname(ln);
     pom.email1(ema);
     pom.mobile1(mob);
     pom.tutiontype(tt);	
     pom.city(city);
     pom.mode(mode);
     pom.enquiry1(enquiry);
     pom.clickloginbutton();
	 //throw new PendingException();
 }

 @Then("^check for messages$")
 public void check_for_messages() throws Throwable 
 {
	 try
	  {
		  String t=d.switchTo().alert().getText();
		  System.out.println(t);
		  d.switchTo().alert().accept();
		  if(t.equalsIgnoreCase("Thank you for submitting the online coaching Class Enquiry"))
		  {
			  System.out.println("on entering all the fields and clicking submit alert with text appeared-No defect");
		  }
		  else
		  {
			  System.out.println("on entering all the fields and clicking submit alert with text did not appear-A defect");

		  }
	  }
	  catch(Exception e)
	  {
		  System.out.println("alert did not appear");
	  }
	 
	 boolean aq1=d.getPageSource().contains("Our Counselor will contact you soon.");
	    if(aq1) 
	    {
	        System.out.println("Text Our Counselor will contact you soon. is present-No defect");

	    }
	    else
	    {
	        System.out.println("Text Our Counselor will contact you soon. is not present-A defect");
	    }
     // throw new PendingException();
 }
 @After
 public void afterScenario()
 {
     //System.out.println("This will run after the Scenario");
     d.close();
 }
 /**
 @After
 public void afterScenario()
 {
     System.out.println("This will run after the Scenario");
    // d.close();
 }
 */
}
