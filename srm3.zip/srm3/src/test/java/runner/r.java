package runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\Admin\\eclipse-workspace\\madhu1\\srm3\\src\\test\\java\\features\\a.feature"}
		,glue="C:\\Users\\Admin\\eclipse-workspace\\madhu1\\srm3\\src\\test\\java\\stepdef\\stepdef.java"
		,plugin = {"pretty", "html:target/akbar-report"}
		,monochrome=true
		,tags= {"@smoke"}		
		)
public class r
{    

}

 